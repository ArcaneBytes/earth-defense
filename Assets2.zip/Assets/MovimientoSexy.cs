﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovimientoSexy : MonoBehaviour
{
	float movimientoNave = 1.5f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    { 
    	if(Input.GetKey(KeyCode.LeftArrow)){
    		if(transform.position.x > -1.6f)
        	gameObject.transform.Translate(-movimientoNave * Time.deltaTime, 0, 0);
        }
       
        if(Input.GetKey(KeyCode.RightArrow)){
        	 if(transform.position.x < 1.6f)
        	gameObject.transform.Translate(movimientoNave * Time.deltaTime, 0, 0);	
       	}
    
        if(Input.GetKey(KeyCode.UpArrow)){
        	if(transform.position.y < -1.4f)
        	gameObject.transform.Translate(0, movimientoNave * Time.deltaTime, 0);	
		}

		if(Input.GetKey(KeyCode.DownArrow)){
			if(transform.position.y > -1.9f)
        	gameObject.transform.Translate(0, -movimientoNave * Time.deltaTime, 0);	
        }
    }
}
