﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemigo1Spawner : MonoBehaviour
{ 
	float timer;
    public GameObject Enemigo1Prefab;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;

        if(timer >= 1.25f)
        {
            timer = 0;
            float random = Random.Range(-1.6f, 1.6f);
            Vector3 position = new Vector3(random, 1.7f, 0);
            Quaternion rot = new Quaternion();
            Instantiate(Enemigo1Prefab, position, rot);

        }

    }
}
